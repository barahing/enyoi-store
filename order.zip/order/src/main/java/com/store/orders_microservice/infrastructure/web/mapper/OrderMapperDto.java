package com.store.orders_microservice.infrastructure.web.mapper;

import org.mapstruct.Mapper;
import com.store.orders_microservice.domain.model.Order;
import com.store.orders_microservice.infrastructure.web.dto.OrderRequestDto;
import com.store.orders_microservice.infrastructure.web.dto.OrderResponseDto;

@Mapper(componentModel = "spring")
public interface OrderMapperDto {
    Order toDomain(OrderRequestDto requestDto);
    OrderResponseDto toResponseDto(Order order);
}
