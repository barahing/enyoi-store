package com.store.orders_microservice.domain.model;

public enum OrderStatus {

}
