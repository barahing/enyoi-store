package com.store.orders_microservice.infrastructure.entity;

public class OrderItemEntity {

}
