package com.store.orders_microservice.domain.model;

import java.math.BigDecimal;
import java.util.UUID;

public record OrderItem (
    UUID productId,
    Integer quantity,
    BigDecimal price,
    BigDecimal subtotal
) {

    public OrderItem calculateSubtotal (Integer quantity, BigDecimal price) {
        BigDecimal quantityBigDecimal = new BigDecimal(quantity);
        BigDecimal newSubtotal = quantityBigDecimal.multiply(price);
        OrderItem orderItemUpdated = new OrderItem(this.productId, this.quantity, this.price, newSubtotal);
        return orderItemUpdated;
    }
}

