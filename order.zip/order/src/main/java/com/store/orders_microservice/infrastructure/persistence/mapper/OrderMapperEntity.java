package com.store.orders_microservice.infrastructure.persistence.mapper;

import org.mapstruct.Mapper;

import com.store.orders_microservice.domain.model.Order;
import com.store.orders_microservice.infrastructure.entity.OrderEntity;

@Mapper
public interface OrderMapperEntity {
    Order toDomain (OrderEntity entity);
    OrderEntity toEntity (Order domain);
}
