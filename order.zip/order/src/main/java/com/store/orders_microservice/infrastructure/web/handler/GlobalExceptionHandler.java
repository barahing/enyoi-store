package com.store.orders_microservice.infrastructure.web.handler;

public class GlobalExceptionHandler {

}
